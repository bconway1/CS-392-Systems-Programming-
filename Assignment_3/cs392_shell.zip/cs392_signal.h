//
// Created by bconway on 4/1/19.
// “I pledge my honor that I have abided by the Stevens Honor System.” - Brereton Conway

#ifndef ASSIGNMENT_3_CS392_SIGNAL_H
#define ASSIGNMENT_3_CS392_SIGNAL_H

void signal_handler_init(void);

#endif //ASSIGNMENT_3_CS392_SIGNAL_H
