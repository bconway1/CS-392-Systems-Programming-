//
// Created by bconway on 4/1/19.
// “I pledge my honor that I have abided by the Stevens Honor System.” - Brereton Conway

#ifndef ASSIGNMENT_3_CS392_LOG_H
#define ASSIGNMENT_3_CS392_LOG_H

void log_init(void);
void log_command(char * command);
void close_log(void);

#endif //ASSIGNMENT_3_CS392_LOG_H
