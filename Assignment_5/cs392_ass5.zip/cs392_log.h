//“I pledge my honor that I have abided by the Stevens Honor System.” -Brereton Conway

// Created by bconway on 5/5/19.
//

#ifndef ASSIGNMENT_5_CS392_LOG_H
#define ASSIGNMENT_5_CS392_LOG_H


void cs392_socket_log(struct in_addr addr, unsigned short port);

#endif //ASSIGNMENT_5_CS392_LOG_H
