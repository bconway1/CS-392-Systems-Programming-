//
// I pledge my honor that I have abided by the Stevens Honor System - Brereton Conway
//

#ifndef MIDTERM_CS392_MIDTERM_H
#define MIDTERM_CS392_MIDTERM_H
char *cs392_strcpy(char *dest, char *src);
int cs392_strcmp(char *s1, char *s2);
char *cs392_strncat(char *dest, char *src, unsigned n);
#endif //MIDTERM_CS392_MIDTERM_H
